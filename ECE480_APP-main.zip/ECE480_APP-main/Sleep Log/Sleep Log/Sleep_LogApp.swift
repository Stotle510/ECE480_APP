//
//  Sleep_LogApp.swift
//  Sleep Log
//
//  Created by James on 10/7/21.
//

import SwiftUI

@main
struct Sleep_LogApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

struct Sleep_LogApp_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
